import subprocess


def main():
    """
    Almost definitely not required, just don't have a thorough knowledge of 
    creating command line tools
    """
    subprocess.run(["streamlit", "run", "app.py"])  
